# Fencing benchmark — StatePact Redis, ZooKeeper+Redis Lua, etcd+PostgreSQL, StatePact PostgreSQL

Real-service benchmark of lease fencing. Two independent client processes (A, B) use
real Redis 7.0.15, ZooKeeper 3.9.3, etcd 3.5.21 and PostgreSQL 16 — no in-memory mutex.

Nothing in the original repositories (`mh`, FineCore, FineCode) was touched. This
directory contains no commits, pushes or merges; it is untracked working output.

## Layout

| path | content |
|---|---|
| `scripts/setup_env.sh` | builds the Python venv, ZooKeeper jars, etcd binary; creates the PG role; starts services |
| `scripts/services.py` | start / stop / SIGKILL / restart for redis-p, redis-r, etcd, zk, pg (PID tracked) |
| `scripts/adapters.py` | the four candidates + negative control, one interface, shared status codes |
| `scripts/worker.py` | one independent client process (role A or B), JSON-line protocol |
| `scripts/run_bench.py` | scenarios, orchestration, violation definitions |
| `scripts/analyze.py` | builds `results.json` and `results_tables.md` from `raw/` only |
| `scripts/run_all.sh` | full run: phase1 then phase2, then analysis |
| `patches/` | the only adaptation needed to run a candidate (etcd launcher, see below) |
| `tools/etcd-embed/` | Go launcher source; `tools/etcd` is its built binary |
| `raw/` | per-run JSON lines (`raw/<impl>/<scenario>.jsonl`), worker stderr, phase logs |
| `RESULTS.md` | comparison and classification |
| `results.json` | structured results (generated) |

## Versions

- Redis server 7.0.15 (AOF `appendfsync always`; replica `redis-r` with async replication)
- PostgreSQL 16.15 (Ubuntu 24.04 package), cluster `main`, port 5432
- etcd v3.5.21, built from `go.etcd.io/etcd/server/v3@v3.5.21` with `patches/etcd-embed-launcher.go.txt`
  (`go install` of the etcd repository's own main is refused by its `replace` directives)
- ZooKeeper 3.9.3 standalone (Maven `org.apache.zookeeper:zookeeper:3.9.3` + runtime jars)
- StatePact 0.1.2 from PyPI (wheel sha256 `1794ac8d9dad33a3e0d8a9978e052e56590a2d501b3019a2af69f43105699b0d`)
- Python 3.13, redis-py 8.1.0, asyncpg 0.32.0, kazoo 2.11.0, httpx 0.28.1
- Benchmark code commit: the HEAD of `oigorbrito/rusky` recorded in `results.json` (`repo_head_commit`)

## Reproduce

```bash
bash scripts/setup_env.sh        # venv, jars, etcd build, PG role/db, start services
REPS=100 bash scripts/run_all.sh # phase1 (parallel 4) + phase2 (serial) + analysis
```

Requirements: `redis-server`, `redis-cli`, PostgreSQL 16 server with `pg_ctlcluster`
(`bench` role is created as superuser for the benchmark only), Java 17+, Maven, Go 1.24, Python 3.13.

## Protocol (per run)

Lease TTL = 1.0 s. A suspended with `SIGSTOP` after acquiring; expiry wait = TTL + 0.5 s.
Writes use the candidate's own commit path. Clients retry the same `opid` on errors.

Scenarios (100 repetitions each, per implementation):

| id | what it does |
|---|---|
| `D2` | A acquires, is suspended before writing; lease expires; B acquires, writes, replays the same opid; A resumes and writes |
| `C4` | as D2, but B also releases the lease (adoption complete) before A resumes |
| `CONC` | A keeps committing while its lease expires; B probes acquisition from just before expiry |
| `EXP_PRE` | A writes, lease expires, A writes again before any new owner |
| `EXP_POST` | A writes, lease expires, B acquires and writes, A writes |
| `LAT` | 10 × (acquire, write, release) per repetition, sequential |
| `PGRACE` | StatePact PG only: A's commit reads the token, then is held by a row lock on `statepact_meta`; B's `acquire_lease()` runs and commits; then A's commit is released |
| `RESTART` | graceful restart of the coordinator between owners; persistence and token monotonicity |
| `INTERRUPT` | coordinator SIGKILLed at a random 0–20 ms into B's acquire, then into B's write (same opid retried) |
| `FAILOVER` | Redis only: primary SIGKILLed right after B's acknowledged write, replica promoted (async), C acquires, A resumes |
| `NEG_D2` | negative control: D2 sequence on Redis with lease timing but no fencing check |

## Violation definitions

- `superseded_accepted`: a write by A returned ok after another owner's acquire was acknowledged. Must be 0.
- `expired_accepted`: a write by A returned ok after A's TTL elapsed, before any other owner acquired. Reported separately (lease-expiry gap, not a token-order violation).
- `applied_after_supersession` (PGRACE): A's write was accepted while its commit was held, and that hold was released only after B's acquire was acknowledged. Storage applied the old token after the new lease was already committed.
- `overlap_accepted`: informational. Overlapping client intervals are not automatically a violation for atomic designs.
- `monotonic_violation`: a newly acquired token ≤ an earlier issued token.
- `valid_rejected`: the current owner's final write refused.
- `duplicate_effects` / `lost_effect`: version delta for one logical write minus one; replays that produced a second effect.
- `final_mismatch`: stored value differs from the last accepted write.

Times come from `CLOCK_MONOTONIC`, which is system-wide on Linux, so timestamps from
the separate A/B processes are comparable.

## Limitations of this reproduction

- Single host, single node per coordinator (no Redis Sentinel/Cluster, no etcd cluster, ZooKeeper standalone). Failover results apply to Redis async replication only.
- Clients reconnect explicitly after an error (one `reconfigure` per failed call); no client-library reconnect policy is measured.
- Latency numbers are worker-side store time (excluding IPC), measured under 4-way parallel load for phase1 and unloaded for PGRACE/phase2.
- The superuser `bench` role is a benchmark convenience, not a production setting.
