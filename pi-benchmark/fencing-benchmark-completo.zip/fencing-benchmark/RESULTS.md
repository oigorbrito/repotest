# Fencing benchmark — results and classification

All numbers come from `raw/` through `scripts/analyze.py` (`results.json`, `results_tables.md`).
Reproduction steps are in `README.md`.

## Provenance

| item | value |
|---|---|
| Repository HEAD of `oigorbrito/rusky` | `d4ba89892ea0ab61cddebfca895d945ae856411c` (benchmark is untracked; nothing committed) |
| Harness fingerprint (sha256 of `scripts/*.py`, `scripts/*.sh`, `tools/etcd-embed/main.go`) | `fcea4f770fcfc4b64c9931746873b0debc4c0572ded82563dff25149aa67c6d6` |
| StatePact | 0.1.2 (PyPI wheel sha256 `1794ac8d9dad33a3e0d8a9978e052e56590a2d501b3019a2af69f43105699b0d`) |
| Redis | 7.0.15, AOF `appendfsync always`; replica 6380 async |
| PostgreSQL | 16.15, one cluster |
| etcd | v3.5.21, single member, built from `go.etcd.io/etcd/server/v3@v3.5.21` (launcher in `patches/`) |
| ZooKeeper | 3.9.3 standalone |
| Lease TTL | 1.0 s; suspension and expiry wait TTL + 0.5 s |
| Repetitions | **100 per scenario per implementation** (2 500 phase-1 runs, 1 100 phase-2 runs, 0 exceptions) |
| Parallelism | phase 1: 4 concurrent slots; phase 2: serial (coordinators are killed) |

## Verdicts per scenario (100 runs each)

| impl | D2 | C4 | CONC | EXP_PRE | EXP_POST | LAT | PGRACE | RESTART | INTERRUPT | FAILOVER |
|---|---|---|---|---|---|---|---|---|---|---|
| statepact_redis | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | PASS |
| zk_redis_lua | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | PASS |
| etcd_pg | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | NÃO TESTADO |
| statepact_pg | PASS | PASS | 95 PASS / 5 FAIL | FAIL | PASS | PASS | **FAIL 100/100** | PASS | PASS | NÃO TESTADO |
| naive_redis (control) | — | — | — | — | — | — | — | — | — | — | D2 sequence: **CONTROL_DETECTED 100/100** |

`EXP_PRE` fails for every implementation (see the expiry gap below). `PGRACE` is the race the protocol asked us to test; it runs only on StatePact PostgreSQL.

## Safety counters (sums over 100 runs)

| impl | scenario | superseded accepted | expired accepted | overlap (informational) | applied after supersession | valid rejected | monotonic violations | duplicates | lost effects | final mismatch |
|---|---|---|---|---|---|---|---|---|---|---|
| statepact_redis | D2, C4, FAILOVER, RESTART, INTERRUPT, LAT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | CONC | 0 | 98 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | EXP_PRE | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | D2, C4, FAILOVER, RESTART, INTERRUPT, LAT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | CONC | 0 | 513 | 13 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | EXP_PRE | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | D2, C4, RESTART, INTERRUPT, LAT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | CONC | 0 | **13 547** | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | EXP_PRE | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | D2, C4, RESTART, INTERRUPT, LAT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | CONC | 0 | 2 | 24 | 0 | **5** | 0 | 0 | 0 | 0 |
| statepact_pg | EXP_PRE | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | PGRACE | 0 | 100 | 100 | **100** | 0 | 0 | 0 | 0 | 0 |
| naive_redis | D2 (control) | **100** | 0 | 0 | 0 | 0 | **100** | **100** | 0 | **100** |

Notes on the counters:
- `valid rejected` for `statepact_pg` CONC: the final write of B returned `conflict`
  (optimistic-concurrency version check), not `rejected_fence`. Stale writes from the
  expired owner had been accepted in the same window and changed the version. This is
  a consequence of the expiry gap, not a fencing decision.
- `applied after supersession` (PGRACE): A's commit was held inside its transaction after
  it had read the old token; B's `acquire_lease()` was acknowledged while A was held; then
  A's commit was released and accepted. The release is ordered after B's acknowledgement,
  so the old token was applied after the new lease was committed. The final value was still
  B's, because the commit lock and OCC prevented a lost update in this run.

## Operational metrics

### Latency (worker-side store time, pooled over all scenarios, ms)

Measured under 4-way parallel load for phase 1 and serial load for phase 2.

| impl | op | n | p50 | p95 | p99 |
|---|---|---|---|---|---|
| statepact_redis | write | 52 401 | 1.585 | 2.536 | 3.594 |
| statepact_redis | acquire | 3 011 | 1.073 | 3.155 | 123.1 |
| statepact_redis | release | 1 100 | 0.592 | 1.113 | 1.887 |
| zk_redis_lua | write | 99 419 | 0.660 | 1.114 | 1.691 |
| zk_redis_lua | acquire | 2 990 | 3.713 | 11.303 | 603.573 |
| zk_redis_lua | release | 1 100 | 0.617 | 1.203 | 1.771 |
| etcd_pg | write | 66 691 | 1.606 | 3.302 | 5.213 |
| etcd_pg | acquire | 4 350 | 9.450 | 565.449 | 887.66 |
| etcd_pg | release | 1 100 | 2.981 | 5.683 | 9.635 |
| statepact_pg | write | 15 312 | 7.189 | 10.229 | 17.179 |
| statepact_pg | acquire | 2 900 | 2.804 | 5.165 | 6.521 |
| statepact_pg | release | 1 100 | 0.914 | 1.901 | 3.404 |

### Coordinator failure (INTERRUPT: SIGKILL at a random 0–3 ms into B's acquire)

| impl | acquire actually interrupted | acquire recovery p50 / p95 / max (ms) | write actually interrupted |
|---|---|---|---|
| statepact_redis | 43 / 100 | 4 174 / 4 905 / 4 986 | 0 / 100 |
| zk_redis_lua | 97 / 100 | 716 / 1 208 / 10 673 | 0 / 100 |
| etcd_pg | 100 / 100 | 810 / 1 014 / 1 056 | 0 / 100 |
| statepact_pg | 0 / 100 | — (kill never reached the operation) | 0 / 100 |

Effects per logical write after recovery: 1 in all 400 runs (no duplicate, no loss).

**Interruption during the write was not exercised in any run.** The kill always came after the
write had already returned. This is reported as NÃO TESTADO below.

### Restart and monotonicity (RESTART scenario)

All four implementations: 100/100 PASS. The persisted value was readable after restart, and
the new token was strictly greater than the previous one.

### Failover (Redis only)

StatePact Redis and ZooKeeper+Redis: 100/100 PASS for `FAILOVER`. The promoted replica
issued a token greater than the previous one, and the stale writer's token was rejected.
The replica was verified as `master` after promotion and as `master_link_status:up` after
restoration; every run had a synced replica before the primary was killed.

## Classification

| impl | classification | evidence and reasons |
|---|---|---|
| **StatePact Redis** | **APROVADA COM LIMITAÇÕES** | 0 superseded writes accepted, 0 monotonic violations, 0 duplicates, 0 lost effects across D2, C4, CONC (superseded), RESTART, INTERRUPT (acquire), FAILOVER, LAT. Commit and acquire are single Lua scripts. Limitations: expired-owner writes accepted (EXP_PRE 100/100 FAIL; CONC 98 expired accepted); write-interruption not exercised; failover loss window not hit (kill ≥1.5 s after ack, replication already caught up). |
| **ZooKeeper + Redis Lua** | **APROVADA COM LIMITAÇÕES** | Same safety counters as StatePact Redis (all zero for superseded writes, monotonicity, duplicates, lost effects). Token is a ZooKeeper persistent-sequential number, monotonic across ZooKeeper restarts. Limitations: EXP_PRE 100/100 FAIL; CONC 513 expired accepted; ZooKeeper tested standalone (no quorum); write-interruption not exercised; ZooKeeper outage causes ~0.7 s p50 acquire outage with a 10.7 s max. |
| **etcd + PostgreSQL** | **APROVADA COM LIMITAÇÕES** | Same safety counters as the above in D2, C4, CONC (superseded = 0), RESTART, INTERRUPT (acquire). Commit validation and the row lock that also serialises the lease adoption work as designed. Limitations: EXP_PRE 100/100 FAIL; CONC shows **13 547 expired-owner writes accepted** because etcd removes the lease key with a lag after TTL, which is the largest expiry gap measured; single-member etcd; FAILOVER not tested (no PostgreSQL replica); write-interruption not exercised. |
| **StatePact PostgreSQL** | **REPROVADA** | PGRACE is the required race test: 100/100 runs applied an old-token commit after the new lease's acquisition was acknowledged (`applied_after_supersession`=100). This is a storage-level invariant violation, reproduced deterministically with a row lock. CONC also produced 5 valid final writes refused by OCC after expired-owner writes. The other scenarios pass. Not tested: FAILOVER (no replica), write-interruption. |
| naive_redis (control) | CONTROL (not a candidate) | CONTROL_DETECTED 100/100: superseded writes, repeated token, duplicate effects and a wrong final value are all flagged. |

No candidate reaches APROVADA: `EXP_PRE` fails 100/100 for each implementation, so none meets the full
protocol. The three "COM LIMITAÇÕES" rows are the ones whose failures are all about lease expiry, and
their superseded-writer protection held in every run.

## NÃO TESTADO (not run, never counted as passed)

- Coordinator killed **during a write** (in-flight commit with lost acknowledgement, retried with the same opid): 0 of 400 runs interrupted a write. The duplicate-effect check relies on the replay probe in D2 and on version deltas in INTERRUPT, not on a true write-interruption.
- FAILOVER for etcd+PostgreSQL and StatePact PostgreSQL: no replica was configured for PostgreSQL or etcd.
- Replication loss for the Redis failover: the scenario ran with the replica synced for ≥1.5 s before the kill, so the unreplicated-write window was not reproduced. The "acknowledged write lost" condition was not measured as a separate metric.
- Multi-node coordinators (Redis Sentinel/Cluster, ZooKeeper ensemble, etcd cluster).
- Latency at zero load: phase 1 ran 4-way parallel.
- `mh`, FineCode and FineCore: not present in this environment (the working tree only has the benchmark notes). Nothing there was read or modified, and no change to `mh` is recommended, because no `mh` implementation was available to compare against its current behaviour.

## Operational cost and dependencies

| impl | services needed | acquire round trips | notes |
|---|---|---|---|
| StatePact Redis | Redis 7 (AOF) + Python package | 1 Lua call | simplest; loses unreplicated writes on failover (not reproduced here) |
| ZooKeeper + Redis | ZooKeeper (JVM, ensemble in production) + Redis | ZK create + Lua | two systems; ZK outage stops acquisition |
| etcd + PostgreSQL | etcd (cluster in production) + PostgreSQL | grant + txn + PG adopt | three round trips; PostgreSQL row lock coordinates adoption and commit |
| StatePact PostgreSQL | PostgreSQL only | 1 transaction | fewest dependencies, but the race above is in the commit/acquire path |

## Reproducibility and corrections made during the run

- Stability passes (state/stab*.log) were used to fix the harness; those runs are not in `raw/`.
- One phase-2 attempt for `zk_redis_lua/RESTART` aborted because the ZooKeeper classpath was missing. Its partial record (which had been wrongly marked PASS) was quarantined in `state/debug-logs/` and excluded. The verdict logic was then changed so any exception produces `INVALID_EXCEPTION`, and the run was resumed from that item. No exceptions occur in `raw/`.
- Earlier false positives were fixed before the final run: a duplicate acquire counted as monotonicity violation; the PGRACE applied-after-supersession condition counted a write that finished before the supersession; the interrupt-recovery metric was reported for acquires that were never interrupted.
