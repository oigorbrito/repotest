"""Client adapters for the four fencing candidates and a negative control.

Every adapter exposes the same async interface and returns plain dicts:

  acquire(res, owner, ttl)             -> {"status": ok|held|error, "token": int}
  release(res, owner)                  -> {"status": ok|error}
  write(res, key, value, token, opid, owner)
                                       -> {"status": ok|replay|rejected_fence|conflict|error,
                                           "version": int}
  read(res, key)                       -> {"status": ok|error, "value": ..., "version": int}

Status meanings are shared across candidates so the orchestrator can compare them:
  ok              write/acquire committed by the store
  replay          same opid already applied; no new effect (idempotency)
  rejected_fence  store refused a token older than its highest observed token
  held            lease held by another owner
  conflict        optimistic-concurrency conflict (not a fencing decision)
  error           transport / coordinator failure; the caller may retry

Candidates:
  statepact_redis  StatePact RedisBackend (statepact 0.1.2, Lua commit/acquire)
  zk_redis_lua     ZooKeeper 3.9.3 persistent-sequential token + Redis Lua acquire/commit
  etcd_pg          etcd v3.5.21 lock + revision token; PostgreSQL txn with row lock
  statepact_pg     StatePact PostgresBackend (statepact 0.1.2, advisory-lock commit)
Control:
  naive_redis      same lease timing, NO fencing validation at write time
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from datetime import datetime, timezone
from typing import Any

import asyncpg
import httpx
import redis.asyncio as redis_async
from kazoo.client import KazooClient
from kazoo.exceptions import KazooException

from statepact.core.exceptions import (
    ConflictError,
    KeyNotFoundError,
    LeaseLostError,
    LeaseNotAvailableError,
)
from statepact.core.interfaces import CommitPlan, WriteRecord
from statepact.storage.postgres import PostgresBackend
from statepact.storage.redis import RedisBackend

# --------------------------------------------------------------------------- Lua

# ZooKeeper candidate: lease acquire. The token comes from ZooKeeper (ARGV[2]).
# Redis refuses a token that is not greater than the stored fence, so a stale
# token obtained before a concurrent acquisition cannot regress the fence.
ZK_ACQUIRE_LUA = """
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local owner, token, ttl = ARGV[1], tonumber(ARGV[2]), tonumber(ARGV[3])
local exp = tonumber(redis.call('HGET', KEYS[1], 'expires') or '0')
local holder = redis.call('HGET', KEYS[1], 'owner')
if exp > now and holder ~= owner then
  return cjson.encode({err = 'held', holder = holder})
end
local fence = tonumber(redis.call('GET', KEYS[2]) or '0')
if token <= fence then
  return cjson.encode({err = 'stale_token', fence = fence})
end
redis.call('HSET', KEYS[1], 'owner', owner, 'token', token, 'expires', now + ttl)
redis.call('SET', KEYS[2], token)
return cjson.encode({ok = true, token = token})
"""

# ZooKeeper candidate: commit. Token validation, idempotency and the write happen
# in one script, so no client can interleave between the check and the write.
# KEYS: 1 fence, 2 data hash, 3 version counter, 4 idempotency record
# ARGV: 1 token, 2 key, 3 value, 4 opid
ZK_COMMIT_LUA = """
local prev = redis.call('GET', KEYS[4])
if prev then
  return cjson.encode({ok = true, replay = true, stored = prev})
end
local fence = tonumber(redis.call('GET', KEYS[1]) or '0')
local token = tonumber(ARGV[1])
if token < fence then
  return cjson.encode({err = 'rejected_fence', fence = fence})
end
local ver = redis.call('INCR', KEYS[3])
redis.call('HSET', KEYS[2], ARGV[2], ARGV[3])
local res = cjson.encode({ok = true, version = ver})
redis.call('SET', KEYS[4], res, 'EX', 86400)
return res
"""

ZK_RELEASE_LUA = """
if redis.call('HGET', KEYS[1], 'owner') == ARGV[1] then
  redis.call('DEL', KEYS[1])
  return 1
end
return 0
"""

# Naive control: lease with TTL only, token constant, no fence check on write.
NAIVE_ACQUIRE_LUA = """
local t = redis.call('TIME')
local now = tonumber(t[1]) * 1000 + math.floor(tonumber(t[2]) / 1000)
local exp = tonumber(redis.call('HGET', KEYS[1], 'expires') or '0')
local holder = redis.call('HGET', KEYS[1], 'owner')
if exp > now and holder ~= ARGV[1] then
  return cjson.encode({err = 'held', holder = holder})
end
redis.call('HSET', KEYS[1], 'owner', ARGV[1], 'token', 1, 'expires', now + tonumber(ARGV[2]))
return cjson.encode({ok = true, token = 1})
"""

NAIVE_WRITE_LUA = """
local ver = redis.call('INCR', KEYS[1])
redis.call('HSET', KEYS[2], ARGV[1], ARGV[2])
return cjson.encode({ok = true, version = ver})
"""


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _b64(s: str) -> str:
    return base64.b64encode(s.encode()).decode()


class Adapter:
    name = "base"

    def __init__(self, cfg: dict[str, Any]) -> None:
        self.cfg = cfg
        self.leases: dict[str, Any] = {}

    async def connect(self) -> None:  # pragma: no cover - overridden
        raise NotImplementedError

    async def close(self) -> None:
        return None

    async def ensure_resource(self, res: str) -> None:
        return None

    async def reconnect(self, cfg_update: dict[str, Any]) -> None:
        self.cfg.update(cfg_update)
        await self.close()
        await self.connect()


# ------------------------------------------------------------- StatePact Redis


class StatePactRedis(Adapter):
    name = "statepact_redis"

    async def connect(self) -> None:
        self.client = redis_async.Redis(
            host="127.0.0.1", port=self.cfg["redis_port"], socket_timeout=3,
            socket_connect_timeout=2,
        )
        self.backend = RedisBackend(self.client, prefix="sp")

    async def close(self) -> None:
        try:
            await self.client.aclose()
        except Exception:
            pass

    async def ensure_resource(self, res: str) -> None:
        await self.backend.ensure_resource(res)

    async def acquire(self, res: str, owner: str, ttl: float) -> dict[str, Any]:
        try:
            lease = await self.backend.acquire_lease(res, owner, ttl)
        except LeaseNotAvailableError:
            return {"status": "held"}
        except Exception as exc:  # transport / coordinator failure
            return {"status": "error", "detail": type(exc).__name__}
        self.leases[res] = lease
        return {"status": "ok", "token": lease.token}

    async def release(self, res: str, owner: str) -> dict[str, Any]:
        lease = self.leases.pop(res, None)
        if lease is None:
            return {"status": "ok"}
        try:
            await self.backend.release_lease(lease)
            return {"status": "ok"}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def write(self, res, key, value, token, opid, owner) -> dict[str, Any]:
        try:
            try:
                ver = (await self.backend.read_latest(res, key)).version
            except KeyNotFoundError:
                ver = 0
            plan = CommitPlan(
                transaction_id=opid, agent_id=owner, isolation="snapshot", reads=(),
                writes=(WriteRecord(res, key, value, expected_version=ver),),
                started_at=_now(), fence=token, idempotency_key=opid,
                request_hash=f"{res}|{key}|{value}",
            )
            result = await self.backend.commit(plan)
        except LeaseLostError:  # subclass of ConflictError: check first
            return {"status": "rejected_fence"}
        except ConflictError:
            return {"status": "conflict"}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}
        if result.replayed:
            return {"status": "replay"}
        return {"status": "ok", "version": int(result.commit_version or 0)}

    async def read(self, res, key) -> dict[str, Any]:
        try:
            sv = await self.backend.read_latest(res, key)
            return {"status": "ok", "value": sv.value, "version": int(sv.version)}
        except KeyNotFoundError:
            return {"status": "ok", "value": None, "version": 0}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}


# ----------------------------------------------------------- StatePact PostgreSQL


class StatePactPg(Adapter):
    name = "statepact_pg"

    async def connect(self) -> None:
        self.backend = await PostgresBackend.connect(
            self.cfg["dsn"], min_size=1, max_size=4
        )

    async def close(self) -> None:
        try:
            await self.backend.close()
        except Exception:
            pass

    async def ensure_resource(self, res: str) -> None:
        await self.backend.ensure_resource(res)

    async def acquire(self, res, owner, ttl):
        try:
            lease = await self.backend.acquire_lease(res, owner, ttl)
        except LeaseNotAvailableError:
            return {"status": "held"}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}
        self.leases[res] = lease
        return {"status": "ok", "token": lease.token}

    async def release(self, res, owner):
        lease = self.leases.pop(res, None)
        if lease is None:
            return {"status": "ok"}
        try:
            await self.backend.release_lease(lease)
            return {"status": "ok"}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def write(self, res, key, value, token, opid, owner):
        try:
            try:
                ver = (await self.backend.read_latest(res, key)).version
            except KeyNotFoundError:
                ver = 0
            plan = CommitPlan(
                transaction_id=opid, agent_id=owner, isolation="snapshot", reads=(),
                writes=(WriteRecord(res, key, value, expected_version=ver),),
                started_at=_now(), fence=token, idempotency_key=opid,
                request_hash=f"{res}|{key}|{value}",
            )
            result = await self.backend.commit(plan)
        except LeaseLostError:
            return {"status": "rejected_fence"}
        except ConflictError:
            return {"status": "conflict"}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}
        if result.replayed:
            return {"status": "replay"}
        return {"status": "ok", "version": int(result.commit_version or 0)}

    async def read(self, res, key):
        try:
            sv = await self.backend.read_latest(res, key)
            return {"status": "ok", "value": sv.value, "version": int(sv.version)}
        except KeyNotFoundError:
            return {"status": "ok", "value": None, "version": 0}
        except Exception as exc:
            return {"status": "error", "detail": type(exc).__name__}


# ------------------------------------------------------------ ZooKeeper + Redis


class ZkRedisLua(Adapter):
    name = "zk_redis_lua"

    async def connect(self) -> None:
        self.zk = KazooClient(hosts=f"127.0.0.1:{self.cfg['zk_port']}")
        await asyncio.to_thread(self.zk.start, 5)
        self.r = redis_async.Redis(
            host="127.0.0.1", port=self.cfg["redis_port"], socket_timeout=3,
            socket_connect_timeout=2,
        )
        self.acq = self.r.register_script(ZK_ACQUIRE_LUA)
        self.commit_s = self.r.register_script(ZK_COMMIT_LUA)
        self.release_s = self.r.register_script(ZK_RELEASE_LUA)

    async def close(self) -> None:
        try:
            await asyncio.to_thread(self.zk.stop)
            self.zk.close()
        except Exception:
            pass
        try:
            await self.r.aclose()
        except Exception:
            pass

    async def ensure_resource(self, res: str) -> None:
        await asyncio.to_thread(self.zk.ensure_path, f"/fence/{res}")

    async def _zk_token(self, res: str) -> int:
        # kazoo signature: create(path, value, acl, ephemeral, sequence, makepath)
        path = await asyncio.to_thread(
            self.zk.create, f"/fence/{res}/t-", b"", None, False, True, False
        )
        return int(path[-10:])

    async def acquire(self, res, owner, ttl):
        try:
            for _ in range(5):
                token = await self._zk_token(res)
                raw = await self.acq(
                    keys=[f"zk:lease:{res}", f"zk:fence:{res}"],
                    args=[owner, token, int(ttl * 1000)],
                )
                resp = json.loads(raw)
                if resp.get("ok"):
                    return {"status": "ok", "token": token}
                if resp.get("err") == "held":
                    return {"status": "held"}
                # stale_token: ZooKeeper token older than fence; take a fresh one
            return {"status": "error", "detail": "stale_token_retries_exhausted"}
        except (KazooException, redis_async.RedisError, OSError) as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def release(self, res, owner):
        try:
            await self.release_s(keys=[f"zk:lease:{res}"], args=[owner])
            return {"status": "ok"}
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def write(self, res, key, value, token, opid, owner):
        try:
            raw = await self.commit_s(
                keys=[f"zk:fence:{res}", f"zk:data:{res}", f"zk:ver:{res}", f"zk:idem:{opid}"],
                args=[token, key, value, opid],
            )
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}
        resp = json.loads(raw)
        if resp.get("replay"):
            return {"status": "replay"}
        if resp.get("err") == "rejected_fence":
            return {"status": "rejected_fence"}
        return {"status": "ok", "version": int(resp["version"])}

    async def read(self, res, key):
        try:
            value = await self.r.hget(f"zk:data:{res}", key)
            ver = await self.r.get(f"zk:ver:{res}")
            return {
                "status": "ok",
                "value": value.decode() if value is not None else None,
                "version": int(ver or 0),
            }
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}


# ---------------------------------------------------------------- etcd + PostgreSQL

ETCD_TABLES = """
CREATE TABLE IF NOT EXISTS etcd_fence (res text PRIMARY KEY, token bigint NOT NULL);
CREATE TABLE IF NOT EXISTS etcd_values (
  res text NOT NULL, key text NOT NULL, value text, version bigint NOT NULL,
  PRIMARY KEY (res, key));
CREATE TABLE IF NOT EXISTS etcd_idem (opid text PRIMARY KEY, version bigint NOT NULL);
"""


class EtcdPg(Adapter):
    name = "etcd_pg"

    async def connect(self) -> None:
        # Tables are created once by scripts/run_bench.py init (avoids DDL races).
        self.http = httpx.AsyncClient(base_url=f"http://127.0.0.1:{self.cfg['etcd_port']}",
                                      timeout=3.0)
        self.pool = await asyncpg.create_pool(self.cfg["dsn"], min_size=1, max_size=4,
                                              command_timeout=5)

    async def close(self) -> None:
        try:
            await self.http.aclose()
        except Exception:
            pass
        try:
            await self.pool.close()
        except Exception:
            pass

    async def ensure_resource(self, res: str) -> None:
        async with self.pool.acquire() as c:
            await c.execute(
                "INSERT INTO etcd_fence(res, token) VALUES ($1, 0) ON CONFLICT DO NOTHING", res
            )

    async def _post(self, path: str, body: dict) -> dict:
        r = await self.http.post(path, json=body)
        r.raise_for_status()
        return r.json()

    async def acquire(self, res, owner, ttl):
        lock_key = f"/locks/{res}"
        try:
            grant = await self._post("/v3/lease/grant", {"TTL": max(1, int(round(ttl)))})
            lease_id = int(grant["ID"])
            txn = await self._post("/v3/kv/txn", {
                "compare": [{"key": _b64(lock_key), "target": "CREATE",
                             "result": "EQUAL", "create_revision": 0}],
                "success": [{"request_put": {"key": _b64(lock_key), "value": _b64(owner),
                                             "lease": lease_id}}],
                "failure": [],
            })
            if not txn.get("succeeded"):
                await self._post("/v3/lease/revoke", {"ID": lease_id})
                return {"status": "held"}
            token = int(txn["header"]["revision"])  # etcd revision: strictly increasing
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            return {"status": "error", "detail": type(exc).__name__}
        self.leases[res] = lease_id
        # Adopt the token into PostgreSQL under the same row lock used by commits.
        try:
            async with self.pool.acquire() as c, c.transaction():
                cur = await c.fetchval(
                    "SELECT token FROM etcd_fence WHERE res = $1 FOR UPDATE", res)
                if cur is None:
                    await c.execute("INSERT INTO etcd_fence VALUES ($1, 0)", res)
                    cur = 0
                if token <= int(cur):
                    return {"status": "error", "detail": "token_not_newer"}
                await c.execute("UPDATE etcd_fence SET token = $2 WHERE res = $1", res, token)
        except asyncpg.PostgresError as exc:
            return {"status": "error", "detail": type(exc).__name__}
        return {"status": "ok", "token": token}

    async def release(self, res, owner):
        lease_id = self.leases.pop(res, None)
        if lease_id is None:
            return {"status": "ok"}
        try:
            await self._post("/v3/lease/revoke", {"ID": lease_id})
            return {"status": "ok"}
        except httpx.HTTPError as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def write(self, res, key, value, token, opid, owner):
        try:
            async with self.pool.acquire() as c, c.transaction():
                fence = await c.fetchval(
                    "SELECT token FROM etcd_fence WHERE res = $1 FOR UPDATE", res)
                if fence is None:
                    return {"status": "error", "detail": "unregistered_resource"}
                if token < int(fence):
                    return {"status": "rejected_fence"}
                prev = await c.fetchval("SELECT version FROM etcd_idem WHERE opid = $1", opid)
                if prev is not None:
                    return {"status": "replay"}
                ver = await c.fetchval(
                    "INSERT INTO etcd_values(res, key, value, version) VALUES ($1, $2, $3, 1) "
                    "ON CONFLICT (res, key) DO UPDATE SET value = EXCLUDED.value, "
                    "version = etcd_values.version + 1 RETURNING version",
                    res, key, value)
                await c.execute("INSERT INTO etcd_idem(opid, version) VALUES ($1, $2)", opid, ver)
                return {"status": "ok", "version": int(ver)}
        except (asyncpg.PostgresError, OSError) as exc:
            return {"status": "error", "detail": type(exc).__name__}

    async def read(self, res, key):
        try:
            row = await self.pool.fetchrow(
                "SELECT value, version FROM etcd_values WHERE res = $1 AND key = $2", res, key)
            if row is None:
                return {"status": "ok", "value": None, "version": 0}
            return {"status": "ok", "value": row["value"], "version": int(row["version"])}
        except (asyncpg.PostgresError, OSError) as exc:
            return {"status": "error", "detail": type(exc).__name__}


# ------------------------------------------------------------------ naive control


class NaiveRedis(Adapter):
    """Negative control: lease timing is kept, but writes never check a token."""

    name = "naive_redis"

    async def connect(self) -> None:
        self.r = redis_async.Redis(host="127.0.0.1", port=self.cfg["redis_port"],
                                   socket_timeout=3)
        self.acq = self.r.register_script(NAIVE_ACQUIRE_LUA)
        self.wr = self.r.register_script(NAIVE_WRITE_LUA)

    async def close(self) -> None:
        try:
            await self.r.aclose()
        except Exception:
            pass

    async def acquire(self, res, owner, ttl):
        try:
            resp = json.loads(await self.acq(keys=[f"nv:lease:{res}"],
                                             args=[owner, int(ttl * 1000)]))
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}
        if resp.get("err"):
            return {"status": "held"}
        return {"status": "ok", "token": 1}

    async def release(self, res, owner):
        return {"status": "ok"}

    async def write(self, res, key, value, token, opid, owner):
        try:
            resp = json.loads(await self.wr(keys=[f"nv:ver:{res}", f"nv:data:{res}"],
                                            args=[key, value]))
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}
        return {"status": "ok", "version": int(resp["version"])}

    async def read(self, res, key):
        try:
            value = await self.r.hget(f"nv:data:{res}", key)
            ver = await self.r.get(f"nv:ver:{res}")
            return {"status": "ok", "value": value.decode() if value is not None else None,
                    "version": int(ver or 0)}
        except redis_async.RedisError as exc:
            return {"status": "error", "detail": type(exc).__name__}


REGISTRY = {
    "statepact_redis": StatePactRedis,
    "zk_redis_lua": ZkRedisLua,
    "etcd_pg": EtcdPg,
    "statepact_pg": StatePactPg,
    "naive_redis": NaiveRedis,
}


def now_ns() -> int:
    return time.monotonic_ns()
