"""Orchestrator for the fencing benchmark.

Drives two independent client processes (A and B, see worker.py) against real
coordinators and stores one JSON record per run under raw/.

Subcommands:
  init                       create PostgreSQL role/database/tables (idempotent)
  run <group> [--reps N]     run a group: 'phase1' (non-disruptive, 4 parallel slots),
                             'phase2' (coordinator kill/restart, serial)
  one <impl> <scenario>      single run, for debugging

Scenario ids (see SCENARIOS): D2, C4, CONC, EXP_PRE, EXP_POST, LAT, PGRACE,
RESTART, INTERRUPT, FAILOVER, NEG_D2.

Violation definitions (computed from timestamps of real operations, same clock
for all processes because CLOCK_MONOTONIC is system-wide on Linux):
  superseded_accepted  write by A that returned ok after another owner's acquire
                       had already been acknowledged (safety violation)
  expired_accepted     write by A that returned ok after A's TTL elapsed with no
                       other owner acquired yet (lease-expiry gap, reported apart)
  valid_rejected       final write by the current owner that was not accepted
  monotonic_violation  a newly acquired token is <= a token already issued
  duplicate_effects    version delta for one logical write minus one
  lost_effect          a logical write that was never applied
  final_mismatch       final stored value differs from the last accepted write
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import queue
import random
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import services  # noqa: E402

BENCH = HERE.parent
RAW = BENCH / "raw"
PY = str(BENCH / ".venv" / "bin" / "python")
TTL = 1.0
TTL_NS = int(TTL * 1e9)
DSN = "postgresql://bench:bench@127.0.0.1:5432/fencebench"
CFG_BASE = {"redis_port": 6379, "zk_port": 2181, "etcd_port": 2379, "dsn": DSN}
COORD = {"statepact_redis": "redis-p", "naive_redis": "redis-p",
         "zk_redis_lua": "zk", "etcd_pg": "etcd", "statepact_pg": "pg"}
IMPLS = ["statepact_redis", "zk_redis_lua", "etcd_pg", "statepact_pg"]


class Worker:
    def __init__(self, impl: str, owner: str, log_path: Path) -> None:
        self.impl, self.owner, self.log_path = impl, owner, log_path
        self.seq = 0
        self._spawn()

    def _spawn(self) -> None:
        cfg = dict(CFG_BASE, impl=self.impl, owner=self.owner)
        self.p = subprocess.Popen(
            [PY, str(HERE / "worker.py"), json.dumps(cfg)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=open(self.log_path, "a"), text=True, bufsize=1,
        )

    def call(self, op: str, **kw) -> dict:
        if self.p.poll() is not None:
            self._spawn()
        self.seq += 1
        try:
            self.p.stdin.write(json.dumps(dict(op=op, id=self.seq, **kw)) + "\n")
            self.p.stdin.flush()
            line = self.p.stdout.readline()
        except (BrokenPipeError, OSError):
            line = ""
        if not line:
            self._spawn()
            return {"status": "error", "detail": "worker_died", "op": op}
        return json.loads(line)

    def pid(self) -> int:
        return self.p.pid

    def close(self) -> None:
        try:
            self.call("quit")
        except Exception:
            pass
        try:
            self.p.wait(timeout=3)
        except Exception:
            self.p.kill()


class Run:
    """Collects the ordered event log of one scenario run."""

    def __init__(self, impl: str, scenario: str, rep: int, res: str,
                 A: Worker, B: Worker, t_origin: int) -> None:
        self.impl, self.scenario, self.rep, self.res = impl, scenario, rep, res
        self.A, self.B = A, B
        self.t_origin = t_origin
        self.events: list[dict] = []
        self.notes: list[str] = []

    def ev(self, actor: str, op: str, resp: dict, **extra) -> dict:
        rec = {"actor": actor, "op": op, "status": resp.get("status"),
               "detail": resp.get("detail"), "t0": resp.get("t0", 0) - self.t_origin,
               "t1": resp.get("t1", 0) - self.t_origin, **extra}
        for k in ("token", "version", "value"):
            if k in resp:
                rec[k] = resp[k]
        self.events.append(rec)
        return rec

    def worker(self, actor: str) -> Worker:
        return self.A if actor == "A" else self.B

    def call(self, actor: str, op: str, **kw) -> dict:
        resp = self.worker(actor).call(op, **kw)
        extra = {k: kw[k] for k in ("owner", "key", "opid", "value", "ttl", "final")
                 if k in kw}
        self.ev(actor, op, resp, **extra)
        return resp

    def reconfigure(self, actor: str, **cfg) -> None:
        self.worker(actor).call("reconfigure", cfg=cfg)

    def acquire(self, actor: str, owner: str, deadline_s: float = 6.0) -> dict:
        end = time.monotonic() + deadline_s
        errors = 0
        while True:
            resp = self.call(actor, "acquire", res=self.res, owner=owner, ttl=TTL)
            if resp.get("status") == "ok":
                return resp
            if resp.get("status") == "error":
                errors += 1
                if errors == 1:
                    self.reconfigure(actor, **_reconnect_cfg(self))
            if time.monotonic() > end:
                return resp
            time.sleep(0.01)

    def write(self, actor: str, owner: str, key: str, value: str, token, opid: str,
              final: bool = True) -> dict:
        return self.call(actor, "write", res=self.res, key=key, value=value,
                         token=token, opid=opid, owner=owner, final=final)

    def write_until(self, actor: str, owner: str, key: str, value: str, token,
                    opid: str, deadline_s: float = 15.0) -> dict:
        """Client retry loop: resend the SAME opid until ok or replay (idempotent)."""
        end = time.monotonic() + deadline_s
        errors = 0
        while True:
            resp = self.call(actor, "write", res=self.res, key=key, value=value,
                             token=token, opid=opid, owner=owner, final=False)
            if resp.get("status") in ("ok", "replay", "rejected_fence"):
                return resp
            if resp.get("status") == "error":
                errors += 1
                if errors == 1:
                    self.reconfigure(actor, **_reconnect_cfg(self))
            if time.monotonic() > end:
                return resp
            time.sleep(0.05)

    def read(self, actor: str, key: str = "k") -> dict:
        return self.call(actor, "read", res=self.res, key=key)

    def read_until(self, actor: str, key: str = "k", deadline_s: float = 15.0) -> dict:
        end = time.monotonic() + deadline_s
        errors = 0
        while True:
            resp = self.read(actor, key)
            if resp.get("status") == "ok":
                return resp
            errors += 1
            if errors == 1:
                self.reconfigure(actor)
            if time.monotonic() > end:
                return resp
            time.sleep(0.05)


def _reconnect_cfg(run: Run) -> dict:
    return {}


def _sleep(s: float) -> None:
    time.sleep(s)


def _stop(w: Worker) -> None:
    os.kill(w.pid(), signal.SIGSTOP)


def _cont(w: Worker) -> None:
    os.kill(w.pid(), signal.SIGCONT)


def _uid(run: Run, tag: str) -> str:
    return f"{run.res}:{tag}"


# --------------------------------------------------------------------- scenarios


def s_D2(r: Run) -> None:
    """Stale writer suspended before its write; new owner writes; stale writer resumes."""
    r.call("A", "setup", res=r.res)
    r.call("B", "setup", res=r.res)
    a = r.acquire("A", "A")
    if a.get("status") != "ok":
        r.notes.append("A could not acquire")
        return
    _stop(r.A)                                  # A suspended between acquire and write
    _sleep(TTL + 0.5)                           # lease expires
    b = r.acquire("B", "B")
    r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))
    # replay probe: the same logical write sent again must not create a second effect
    r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"), final=False)
    _cont(r.A)
    r.reconfigure("A")
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("B")


def s_C4(r: Run) -> None:
    """Stale writer resumes after the new owner has adopted the lease AND released it."""
    r.call("A", "setup", res=r.res)
    r.call("B", "setup", res=r.res)
    a = r.acquire("A", "A")
    _stop(r.A)
    _sleep(TTL + 0.5)
    b = r.acquire("B", "B")
    r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))
    r.call("B", "release", res=r.res, owner="B")
    _sleep(0.2)
    _cont(r.A)
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("B")


def s_EXP_PRE(r: Run) -> None:
    """Writer writes normally, lease expires, writer writes again before any new owner."""
    r.call("A", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _sleep(TTL + 0.5)
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("A")


def s_EXP_POST(r: Run) -> None:
    """Writer writes, lease expires, new owner acquires and writes, writer tries again."""
    r.call("A", "setup", res=r.res)
    r.call("B", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _sleep(TTL + 0.5)
    b = r.acquire("B", "B")
    r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("B")


def s_CONC(r: Run) -> None:
    """A keeps committing while its lease expires; B acquires concurrently."""
    r.call("A", "setup", res=r.res)
    a = r.acquire("A", "A")
    t_expire_ns = a["t1"] + TTL_NS
    stop_flag = threading.Event()
    n = {"i": 0}

    def a_loop() -> None:
        end = t_expire_ns + int(0.4 * 1e9)  # keep writing ~0.4 s past nominal expiry
        while time.monotonic_ns() < end and not stop_flag.is_set():
            n["i"] += 1
            r.write("A", "A", "k", f"A-{n['i']}", a.get("token"), _uid(r, f"A{n['i']}"))

    def b_loop() -> None:
        # Start probing just before expiry so acquisition and commits overlap.
        wait_s = (t_expire_ns - time.monotonic_ns()) / 1e9 - 0.05
        if wait_s > 0:
            _sleep(wait_s)
        b = r.acquire("B", "B", deadline_s=3.0)
        if b.get("status") == "ok":
            r.write("B", "B", "k", "B-final", b.get("token"), _uid(r, "Bf"))
        stop_flag.set()

    ta = threading.Thread(target=a_loop)
    tb = threading.Thread(target=b_loop)
    ta.start(); tb.start()
    ta.join(); tb.join()
    r.read("B")


def s_LAT(r: Run) -> None:
    """Sequential latency: acquire, write, release, ten times on a fresh resource."""
    r.call("A", "setup", res=r.res)
    for i in range(10):
        a = r.call("A", "acquire", res=r.res, owner="A", ttl=TTL)
        if a.get("status") == "ok":
            r.write("A", "A", "k", f"L-{i}", a.get("token"), _uid(r, f"L{i}"))
        r.call("A", "release", res=r.res, owner="A")


def s_PGRACE(r: Run) -> None:
    """Race between acquire_lease() and _commit_locked() in StatePact PostgreSQL.

    A's commit reads the token, then is held inside its transaction by a row lock on
    statepact_meta (taken by the blocker below). While it waits, B's acquire_lease()
    runs and commits. Then A's commit is released and completes.
    """
    r.call("A", "setup", res=r.res)
    r.call("B", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _sleep(TTL + 0.5)

    blocker = PgBlocker()
    blocker.hold()

    def a_commit() -> None:
        r.write("A", "A", "k", "A-race", a.get("token"), _uid(r, "Arace"))

    th = threading.Thread(target=a_commit)
    th.start()
    blocked = pg_wait_blocked(2.5)
    r.notes.append(f"A commit blocked inside transaction after token read: {blocked}")
    b = r.acquire("B", "B")  # must not wait on A's commit path
    # Causality: A's COMMIT can only run after the blocker is released, and B's acquire
    # was acknowledged before that. Record the release instant on the same clock.
    release_rel = time.monotonic_ns() - r.t_origin
    blocker.release()
    th.join()
    r.events.append({"actor": "orchestrator", "op": "blocker_release", "status": "info",
                     "t0": release_rel, "t1": release_rel})
    r.write("B", "B", "k", "B-2", b.get("token"), _uid(r, "B2"))
    r.read("B")


def s_NEG_D2(r: Run) -> None:
    """Negative control: the D2 sequence against a store with no fencing check."""
    s_D2(r)


def s_RESTART(r: Run) -> None:
    """Graceful restart of the coordinator between two owners; persistence + monotonicity."""
    r.call("A", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _sleep(TTL + 0.5)
    services.restart(COORD[r.impl])
    r.reconfigure("B")
    r.read_until("B")  # a persisted value must still be readable after restart
    b = r.acquire("B", "B")
    r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))
    r.reconfigure("A")
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("B")


def s_INTERRUPT(r: Run) -> None:
    """Coordinator killed (SIGKILL) during B's acquire and then during B's write.

    The client retries the same opid after the coordinator is back.
    """
    r.call("A", "setup", res=r.res)
    r.call("B", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _sleep(TTL + 0.5)
    coord = COORD[r.impl]

    # --- kill during acquire
    kill_t = {}
    th = threading.Thread(target=lambda: kill_t.setdefault(
        "resp", r.call("B", "acquire", res=r.res, owner="B", ttl=TTL)))
    th.start()
    _sleep(random.uniform(0.0, 0.003))
    kill_t["kill_ns"] = time.monotonic_ns()
    services.kill(coord)
    th.join()
    first = kill_t.get("resp", {})
    services.start(coord)
    b = first if first.get("status") == "ok" else r.acquire("B", "B", deadline_s=20.0)
    r.notes.append(f"acquire_first={first.get('status')} acquire_final={b.get('status')}"
                   f" acquire_interrupted={first.get('status') != 'ok'}")
    # Recovery is only meaningful when the first acquire was actually interrupted.
    rec_acq_ms = ((b.get("t1", 0) - kill_t["kill_ns"]) / 1e6
                  if first.get("status") != "ok" and b.get("status") == "ok" else None)

    # --- kill during write (same logical write, retried with same opid)
    v_before = r.read_until("B").get("version", 0)
    wkill = {}
    th = threading.Thread(target=lambda: wkill.setdefault(
        "resp", r.write_until("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))))
    th.start()
    _sleep(random.uniform(0.0, 0.003))
    wkill["kill_ns"] = time.monotonic_ns()
    services.kill(coord)
    services.start(coord)
    th.join()
    wfinal = wkill.get("resp", {})
    first_w = next((e for e in r.events if e["op"] == "write" and e.get("opid") == _uid(r, "B1")),
                   {})
    # Recovery is only meaningful when the first attempt was actually interrupted.
    interrupted = first_w.get("status") not in ("ok", "replay")
    rec_w_ms = ((wfinal.get("t1", 0) - wkill["kill_ns"]) / 1e6
                if interrupted and wfinal.get("status") in ("ok", "replay") else None)
    v_after = r.read_until("B").get("version", 0)
    r.notes.append(f"write_first={first_w.get('status')} write_final={wfinal.get('status')}"
                   f" effects={v_after - v_before} recovery_ms={rec_w_ms}")
    now_rel = time.monotonic_ns() - r.t_origin
    r.events.append({"actor": "B", "op": "interrupt_summary", "status": "info",
                     "t0": now_rel, "t1": now_rel,
                     "effects": v_after - v_before, "recovery_acq_ms": rec_acq_ms,
                     "recovery_write_ms": rec_w_ms, "write_interrupted": interrupted,
                     "acquire_interrupted": first.get("status") != "ok"})
    r.reconfigure("A")
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read_until("B")


def s_FAILOVER(r: Run) -> None:
    """Redis primary crashes right after B's acknowledged write (async replication).

    The replica is promoted. Checks: is B's acknowledged write still there, is the
    fence still there (monotonic next token), and is A's stale token still rejected?
    """
    synced = wait_redis_sync(6380)
    r.notes.append(f"pre_failover_replica_sync={synced}")
    r.call("A", "setup", res=r.res)
    a = r.acquire("A", "A")
    r.write("A", "A", "k", "A-0", a.get("token"), _uid(r, "A0"))
    _stop(r.A)
    _sleep(TTL + 0.5)
    b = r.acquire("B", "B")
    bw = r.write("B", "B", "k", "B-1", b.get("token"), _uid(r, "B1"))
    services.kill("redis-p")
    subprocess.run(["redis-cli", "-p", "6380", "replicaof", "no", "one"],
                   capture_output=True, check=False)
    r.notes.append(f"promoted_role={redis_info(6380, 'role')}")
    r.reconfigure("B", redis_port=6380)
    _sleep(TTL + 0.5)
    c = r.acquire("B", "C")  # new owner after failover, owner id C
    r.write("B", "C", "k", "C-1", c.get("token"), _uid(r, "C1"))
    _cont(r.A)                       # resume A first: a stopped process cannot answer
    r.reconfigure("A", redis_port=6380)
    r.write("A", "A", "k", "A-1", a.get("token"), _uid(r, "A1"))
    r.read("B")
    # restore canonical topology for the next run: primary 6379, replica 6380 resynced
    services.start("redis-p")
    services.kill("redis-r")
    services.start("redis-r")
    r.notes.append(f"restored_sync={wait_redis_sync(6380, 30.0)}")


SCENARIOS = {
    "D2": s_D2, "C4": s_C4, "CONC": s_CONC, "EXP_PRE": s_EXP_PRE, "EXP_POST": s_EXP_POST,
    "LAT": s_LAT, "PGRACE": s_PGRACE, "RESTART": s_RESTART, "INTERRUPT": s_INTERRUPT,
    "FAILOVER": s_FAILOVER, "NEG_D2": s_NEG_D2,
}


# ------------------------------------------------------------------- PG helpers


class PgBlocker:
    """Holds a row lock on statepact_meta from a separate connection."""

    def __init__(self) -> None:
        self.proc = None

    def hold(self) -> None:
        code = (
            "import asyncio,asyncpg,sys\n"
            "async def m():\n"
            f" c=await asyncpg.connect('{DSN}')\n"
            " tr=c.transaction(); await tr.start()\n"
            " await c.execute('SELECT seq FROM statepact_meta WHERE id=1 FOR UPDATE')\n"
            " print('locked',flush=True)\n"
            " sys.stdin.readline()\n"
            " await tr.commit(); await c.close()\n"
            "asyncio.run(m())\n"
        )
        self.proc = subprocess.Popen([PY, "-c", code], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, text=True)
        assert self.proc.stdout.readline().strip() == "locked"

    def release(self) -> None:
        self.proc.stdin.write("go\n")
        self.proc.stdin.flush()
        self.proc.wait(timeout=10)


def redis_info(port: int, field: str) -> str:
    out = subprocess.run(["redis-cli", "-p", str(port), "info", "replication"],
                         capture_output=True, text=True).stdout
    if field == "role":
        for line in out.splitlines():
            if line.startswith("role:"):
                return line.split(":", 1)[1].strip()
        return "unknown"
    return out


def wait_redis_sync(port: int, timeout_s: float = 15.0) -> bool:
    end = time.monotonic() + timeout_s
    while time.monotonic() < end:
        if "master_link_status:up" in redis_info(port, "all"):
            return True
        time.sleep(0.05)
    return False


def pg_wait_blocked(timeout_s: float) -> bool:
    end = time.monotonic() + timeout_s
    while time.monotonic() < end:
        out = subprocess.run(
            ["psql", "-h", "127.0.0.1", "-U", "bench", "-d", "fencebench", "-tAc",
             "SELECT count(*) FROM pg_stat_activity WHERE wait_event_type='Lock' "
             "AND query ILIKE '%statepact_meta%'"],
            capture_output=True, text=True, env=dict(os.environ, PGPASSWORD="bench"))
        if out.stdout.strip() not in ("", "0"):
            return True
        time.sleep(0.02)
    return False


def pg_init() -> None:
    env = dict(os.environ)
    cmds = [
        "DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='bench') "
        "THEN CREATE ROLE bench LOGIN SUPERUSER PASSWORD 'bench'; END IF; END $$;",
    ]
    for c in cmds:
        subprocess.run(["runuser", "-u", "postgres", "--", "psql", "-v", "ON_ERROR_STOP=1",
                        "-c", c], check=True, capture_output=True)
    exists = subprocess.run(["runuser", "-u", "postgres", "--", "psql", "-tAc",
                             "SELECT 1 FROM pg_database WHERE datname='fencebench'"],
                            capture_output=True, text=True).stdout.strip()
    if exists != "1":
        subprocess.run(["runuser", "-u", "postgres", "--", "psql", "-c",
                        "CREATE DATABASE fencebench OWNER bench"], check=True,
                       capture_output=True)
    from adapters import ETCD_TABLES  # noqa: WPS433 (local import after env is ready)
    subprocess.run(["psql", "-h", "127.0.0.1", "-U", "bench", "-d", "fencebench", "-v",
                    "ON_ERROR_STOP=1", "-c", ETCD_TABLES], check=True, env=dict(env, PGPASSWORD="bench"),
                   capture_output=True)
    print("pg init ok")


# ------------------------------------------------------------------- evaluation


def evaluate(r: Run, scenario: str) -> dict:
    ev = r.events
    a_acq = next((e for e in ev if e["actor"] == "A" and e["op"] == "acquire"
                  and e["status"] == "ok"), None)
    owners_ok_acq = [e for e in ev if e["op"] == "acquire" and e["status"] == "ok"
                     and e.get("owner") not in (None, "A")]
    m = {"superseded_accepted": 0, "expired_accepted": 0, "overlap_accepted": 0,
         "valid_rejected": 0, "monotonic_violation": 0, "duplicate_effects": 0,
         "lost_effect": 0, "final_mismatch": 0, "stale_probe_rejected": 0}
    # stale writes = writes by A (the old owner) that returned ok
    for e in ev:
        if e["actor"] != "A" or e["op"] != "write" or e["status"] != "ok":
            continue
        sup = [s for s in owners_ok_acq if s["t1"] < e["t0"]]
        if sup:
            m["superseded_accepted"] += 1
        elif a_acq is not None and e["t0"] > a_acq["t1"] + TTL_NS:
            m["expired_accepted"] += 1
        for s in owners_ok_acq:
            if e["t0"] < s["t1"] < e["t1"]:
                m["overlap_accepted"] += 1
                break
    for e in ev:
        if e["actor"] == "A" and e["op"] == "write" and e["status"] == "rejected_fence":
            m["stale_probe_rejected"] += 1
    # duplicates: the same opid accepted as a fresh effect more than once
    seen_opids: set[str] = set()
    for e in sorted(ev, key=lambda x: x["t1"]):
        if e["op"] == "write" and e["status"] == "ok" and e.get("opid"):
            if e["opid"] in seen_opids:
                m["duplicate_effects"] += 1
            seen_opids.add(e["opid"])
    # monotonic tokens across successful acquisitions in time order
    toks = [e["token"] for e in sorted(ev, key=lambda x: x["t1"])
            if e["op"] == "acquire" and e["status"] == "ok" and "token" in e]
    for i in range(1, len(toks)):
        if toks[i] <= max(toks[:i]):
            m["monotonic_violation"] += 1
    # PGRACE: A's commit was held (row lock) until after B's acquire was acknowledged.
    # An A write accepted in that case was applied after the lease had been superseded.
    rel = next((e for e in ev if e["op"] == "blocker_release"), None)
    if rel is not None:
        for e in ev:
            if e["actor"] == "A" and e["op"] == "write" and e["status"] == "ok":
                if e["t1"] > rel["t0"] and any(s["t1"] < rel["t0"] for s in owners_ok_acq):
                    m["applied_after_supersession"] = m.get("applied_after_supersession", 0) + 1
    # valid writes that were refused (final attempts by a non-A actor)
    for e in ev:
        if e.get("final") and e["actor"] == "B" and e["op"] == "write" \
                and e["status"] not in ("ok", "replay"):
            m["valid_rejected"] += 1
    # duplicates / lost effects (interrupt scenario records version deltas)
    for e in ev:
        if "effects" in e and e.get("op") == "write":
            m["duplicate_effects"] += max(0, e["effects"] - 1)
            m["lost_effect"] += int(e["effects"] == 0)
        if e.get("op") == "interrupt_summary":
            m["duplicate_effects"] += max(0, e["effects"] - 1)
            m["lost_effect"] += int(e["effects"] == 0)
    # final value check: the last accepted write by B must be what the store holds
    b_ok = [e for e in ev if e["actor"] == "B" and e["op"] == "write" and e["status"] == "ok"
            and e.get("value")]
    final = [e for e in ev if e["op"] == "read" and e["actor"] == "B"]
    if b_ok and final and final[-1].get("value") is not None:
        if final[-1]["value"] != b_ok[-1]["value"]:
            m["final_mismatch"] += 1
    # latency samples (store-side, worker timing), in ms
    lat = {"acquire": [], "write": [], "release": []}
    for e in ev:
        if e["op"] in lat and e["status"] in ("ok", "replay", "held"):
            lat[e["op"]].append((e["t1"] - e["t0"]) / 1e6)
    m["op_errors"] = sum(1 for e in ev if e["status"] == "error")
    return {"metrics": m, "latency_ms": lat}


def verdict(scenario: str, m: dict, invalid: bool = False) -> str:
    if invalid:
        return "INVALID_PRECONDITION"
    if scenario == "EXP_PRE":
        return "PASS" if m["expired_accepted"] == 0 else "FAIL"
    if scenario == "NEG_D2":
        return "CONTROL_DETECTED" if (m["superseded_accepted"] > 0
                                      or m["final_mismatch"] > 0) else "CONTROL_MISSED"
    if scenario == "LAT":
        return "PASS" if m.get("op_errors", 0) == 0 else "FAIL"
    bad = (m["superseded_accepted"] + m["monotonic_violation"] + m["valid_rejected"]
           + m["duplicate_effects"] + m["lost_effect"] + m["final_mismatch"]
           + m.get("applied_after_supersession", 0))
    return "PASS" if bad == 0 else "FAIL"


def _invalid(r: Run, scenario: str) -> bool:
    """A failover run is only evidence if the replica was synced and C acquired."""
    if scenario != "FAILOVER":
        return False
    if "pre_failover_replica_sync=False" in r.notes:
        return True
    return not any(e["op"] == "acquire" and e.get("owner") == "C" and e["status"] == "ok"
                   for e in r.events)


def execute(impl: str, scenario: str, rep: int, A: Worker, B: Worker) -> dict:
    res = f"{scenario.lower()}-{impl}-{rep}-{os.getpid()}-{random.randrange(1 << 30)}"
    # Workers are reused across repetitions: reset any port left by a previous FAILOVER.
    for w in (A, B):
        w.call("reconfigure", cfg={"redis_port": 6379})
    t_origin = time.monotonic_ns()
    r = Run(impl, scenario, rep, res, A, B, t_origin)
    try:
        SCENARIOS[scenario](r)
        err = None
    except Exception as exc:  # record, do not hide
        err = f"{type(exc).__name__}: {exc}"
    ev_stats = evaluate(r, scenario)
    rec = {"impl": impl, "scenario": scenario, "rep": rep, "resource": res,
           "exception": err, "notes": r.notes, "metrics": ev_stats["metrics"],
           "latency_ms": ev_stats["latency_ms"],
           "verdict": ("INVALID_EXCEPTION" if err else
                       verdict(scenario, ev_stats["metrics"], invalid=_invalid(r, scenario))),
           "events": r.events}
    return rec


def _make_pair(impl: str, tag: str) -> tuple[Worker, Worker]:
    RAW.mkdir(parents=True, exist_ok=True)
    logp = RAW / f"worker-{impl}-{tag}.stderr.log"
    return Worker(impl, "A", logp), Worker(impl, "B", logp)


def write_record(rec: dict) -> None:
    d = RAW / rec["impl"]
    d.mkdir(parents=True, exist_ok=True)
    with open(d / f"{rec['scenario']}.jsonl", "a") as f:
        f.write(json.dumps(rec) + "\n")


def group_phase1(reps: int) -> None:
    # PGRACE is serial (phase2 list): its row lock would interfere with parallel runs.
    jobs = []
    for impl in IMPLS:
        jobs += [(impl, s) for s in ["D2", "C4", "CONC", "EXP_PRE", "EXP_POST", "LAT"]]
    jobs.append(("naive_redis", "NEG_D2"))
    pool: queue.Queue = queue.Queue()
    for i in range(4):
        pool.put(i)
    slots: dict[int, tuple[Worker, Worker]] = {}
    lock = threading.Lock()

    def task(impl: str, scen: str, rep: int) -> dict:
        slot = pool.get()
        try:
            key = (slot, impl)
            with lock:
                if key not in slots:
                    slots[key] = _make_pair(impl, f"s{slot}")
            A, B = slots[key]
            rec = execute(impl, scen, rep, A, B)
            write_record(rec)
            return rec
        finally:
            pool.put(slot)

    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(task, impl, scen, rep) for impl, scen in jobs
                for rep in range(reps)]
        done = 0
        for f in cf.as_completed(futs):
            done += 1
            rec = f.result()
            if done % 50 == 0:
                print(f"[phase1] {done}/{len(futs)} last={rec['impl']}/{rec['scenario']}"
                      f" {rec['verdict']}", flush=True)
    for pair in slots.values():
        for w in pair:
            w.close()


PHASE2 = [("statepact_redis", "RESTART"), ("statepact_redis", "INTERRUPT"),
          ("statepact_redis", "FAILOVER"), ("zk_redis_lua", "RESTART"),
          ("zk_redis_lua", "INTERRUPT"), ("zk_redis_lua", "FAILOVER"),
          ("etcd_pg", "RESTART"), ("etcd_pg", "INTERRUPT"),
          ("statepact_pg", "RESTART"), ("statepact_pg", "INTERRUPT"),
          ("statepact_pg", "PGRACE")]
REDIS_BACKED = ("statepact_redis", "zk_redis_lua")


def group_phase2(reps: int, start_index: int = 0) -> None:
    for impl, scen in PHASE2[start_index:]:
        A, B = _make_pair(impl, "p2")
        try:
            for rep in range(reps):
                if scen == "FAILOVER" and impl not in REDIS_BACKED:
                    break
                rec = execute(impl, scen, rep, A, B)
                write_record(rec)
                if rep % 25 == 0:
                    print(f"[phase2] {impl}/{scen} rep={rep} {rec['verdict']}", flush=True)
                # Services are restored after each run so the next run starts clean.
                ensure_services_up()
        finally:
            A.close(); B.close()


def ensure_services_up() -> None:
    st = services.status()
    for name, up in st.items():
        if not up:
            services.start(name)
    # a replica that was restarted must finish its resync before the next failover run
    if services.status()["redis-r"]:
        wait_redis_sync(6380, 30.0)


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    p = sub.add_parser("run")
    p.add_argument("group", choices=["phase1", "phase2"])
    p.add_argument("--reps", type=int, default=100)
    p.add_argument("--start-index", type=int, default=0, help="phase2 item to resume from")
    o = sub.add_parser("one")
    o.add_argument("impl"); o.add_argument("scenario")
    args = ap.parse_args()
    if args.cmd == "init":
        pg_init()
    elif args.cmd == "run":
        if args.group == "phase1":
            group_phase1(args.reps)
        else:
            group_phase2(args.reps, args.start_index)
    elif args.cmd == "one":
        A, B = _make_pair(args.impl, "one")
        rec = execute(args.impl, args.scenario, 0, A, B)
        print(json.dumps({k: rec[k] for k in ("metrics", "verdict", "exception", "notes")},
                         indent=1))
        A.close(); B.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
