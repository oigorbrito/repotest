#!/usr/bin/env bash
# Full benchmark: phase1 (non-disruptive, 4 parallel slots) then phase2 (serial, kills/restarts).
set -euo pipefail
B="$(cd "$(dirname "$0")/.." && pwd)"
cd "$B"
export FENCE_ZK_LIB="$B/state/zk-lib"
REPS="${REPS:-100}"
.venv/bin/python scripts/run_bench.py run phase1 --reps "$REPS" 2>&1 | tee raw/phase1.log
.venv/bin/python scripts/run_bench.py run phase2 --reps "$REPS" 2>&1 | tee raw/phase2.log
.venv/bin/python scripts/analyze.py > raw/analyze.log
echo DONE
