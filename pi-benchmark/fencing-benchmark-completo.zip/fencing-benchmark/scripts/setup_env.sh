#!/usr/bin/env bash
# Reproducible environment for the fencing benchmark (Ubuntu 24.04, x86_64).
# Idempotent: safe to re-run. Does not touch any repository other than fencing-benchmark/.
set -euo pipefail
B="$(cd "$(dirname "$0")/.." && pwd)"
cd "$B"

# 1. Python environment: StatePact 0.1.2 from PyPI + client libraries
python3 -m venv .venv
.venv/bin/pip install -q statepact==0.1.2 redis==8.1.0 asyncpg==0.32.0 kazoo==2.11.0 httpx==0.28.1

# 2. ZooKeeper 3.9.3 + runtime jars from Maven Central into state/zk-lib
mkdir -p state/zk-lib
(cd scripts/zk && mvn -q -B dependency:copy-dependencies -DoutputDirectory="$B/state/zk-lib" \
  -Dmdep.useRepositoryLayout=false)

# 3. etcd v3.5.21 server built from the published module (see patches/)
(cd tools/etcd-embed && GOTOOLCHAIN=local GOPROXY=https://proxy.golang.org GOFLAGS=-mod=mod \
  go build -o "$B/tools/etcd" .)

# 4. PostgreSQL 16 role/database/tables (requires the cluster to be running)
.venv/bin/python scripts/run_bench.py init

# 5. Start coordinators with PID tracking
FENCE_ZK_LIB="$B/state/zk-lib" .venv/bin/python scripts/services.py start redis-p redis-r etcd zk
