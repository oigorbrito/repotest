"""Lifecycle manager for the real coordinators used by the fencing benchmark.

Services (all real processes, no in-memory substitutes):
  redis-p   Redis 7.0.15 primary  127.0.0.1:6379  AOF appendfsync=always
  redis-r   Redis 7.0.15 replica  127.0.0.1:6380  replicaof 6379 (async)
  etcd      etcd v3.5.21 (single member, built from the published module)
  zk        ZooKeeper 3.9.3 standalone (classpath from Maven)
  pg        PostgreSQL 16 cluster main, 127.0.0.1:5432 (database fencebench)

Usage:  python services.py {start|stop|kill|restart|status} <name>...
"""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

BENCH = Path(__file__).resolve().parent.parent
STATE = Path(os.environ.get("FENCE_STATE_DIR", BENCH / "state"))
PIDS = STATE / "pids"
ZK_LIB = Path(os.environ.get("FENCE_ZK_LIB", STATE / "zk-lib"))
ETCD_BIN = BENCH / "tools" / "etcd"
REDIS_SERVER = os.environ.get("REDIS_SERVER", "redis-server")
REDIS_CLI = os.environ.get("REDIS_CLI", "redis-cli")

REDIS_P_PORT = 6379
REDIS_R_PORT = 6380
ETCD_CLIENT = 2379
ZK_PORT = 2181
PG_PORT = 5432


def _ensure_dirs() -> None:
    for d in (STATE, PIDS, STATE / "data", STATE / "conf"):
        d.mkdir(parents=True, exist_ok=True)


def _write_redis_conf(name: str, port: int, replicaof: int | None) -> Path:
    data = STATE / "data" / name
    data.mkdir(parents=True, exist_ok=True)
    lines = [
        f"port {port}",
        "bind 127.0.0.1",
        f"dir {data}",
        "appendonly yes",
        "appendfsync always",
        'save ""',
        f"pidfile {PIDS / (name + '.pid')}",
        f"logfile {STATE / (name + '.log')}",
        "daemonize yes",
        "protected-mode no",
    ]
    if replicaof is not None:
        lines.append(f"replicaof 127.0.0.1 {replicaof}")
    conf = STATE / "conf" / f"{name}.conf"
    conf.write_text("\n".join(lines) + "\n")
    return conf


def _port_open(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.2)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _wait(predicate, timeout: float, what: str) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.05)
    raise RuntimeError(f"timeout waiting for {what}")


def _read_pid(name: str) -> int | None:
    """PID of a live (non-zombie) service process, else None.

    A killed child that was started by this same Python process stays a zombie until
    reaped; kill(pid, 0) would still succeed on it, so its state is checked too.
    """
    p = PIDS / f"{name}.pid"
    if not p.exists():
        return None
    try:
        pid = int(p.read_text().strip())
    except ValueError:
        return None
    try:
        os.kill(pid, 0)
    except OSError:
        return None
    try:
        state = Path(f"/proc/{pid}/stat").read_text().split(") ", 1)[1].split()[0]
        if state == "Z":
            return None
    except (OSError, IndexError):
        return None
    return pid


def _popen(name: str, argv: list[str], env: dict | None = None) -> None:
    log = open(STATE / f"{name}.log", "ab")
    proc = subprocess.Popen(
        argv, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=env
    )
    (PIDS / f"{name}.pid").write_text(str(proc.pid))


def start(name: str) -> None:
    _ensure_dirs()
    if name == "redis-p":
        conf = _write_redis_conf("redis-p", REDIS_P_PORT, None)
        subprocess.run([REDIS_SERVER, str(conf)], check=True)
        _wait(lambda: _port_open(REDIS_P_PORT), 10, "redis-p")
    elif name == "redis-r":
        conf = _write_redis_conf("redis-r", REDIS_R_PORT, REDIS_P_PORT)
        subprocess.run([REDIS_SERVER, str(conf)], check=True)
        _wait(lambda: _port_open(REDIS_R_PORT), 10, "redis-r")
    elif name == "etcd":
        _popen(
            "etcd",
            [str(ETCD_BIN), "--data-dir", str(STATE / "data" / "etcd"),
             "--client", f"http://127.0.0.1:{ETCD_CLIENT}",
             "--peer", "http://127.0.0.1:2380"],
        )
        _wait(lambda: _port_open(ETCD_CLIENT), 20, "etcd")
    elif name == "zk":
        cfg = STATE / "conf" / "zoo.cfg"
        (STATE / "data" / "zk").mkdir(parents=True, exist_ok=True)
        cfg.write_text(
            f"tickTime=2000\ndataDir={STATE / 'data' / 'zk'}\nclientPort={ZK_PORT}\n"
            "admin.enableServer=false\n4lw.commands.whitelist=*\n"
        )
        _popen(
            "zk",
            ["java", "-cp", str(ZK_LIB / "*"),
             "org.apache.zookeeper.server.ZooKeeperServerMain", str(cfg)],
        )
        _wait(lambda: _port_open(ZK_PORT), 30, "zookeeper")
    elif name == "pg":
        subprocess.run(["pg_ctlcluster", "16", "main", "start"], check=True)
        _wait(lambda: _port_open(PG_PORT), 20, "postgres")
    else:
        raise SystemExit(f"unknown service {name}")


def kill(name: str) -> None:
    """Hard crash (SIGKILL / immediate stop). No graceful flush."""
    if name in ("redis-p", "redis-r"):
        pid = _read_pid(name)
        if pid:
            os.kill(pid, signal.SIGKILL)
            _wait(lambda: _read_pid(name) is None, 5, f"{name} exit")
    elif name in ("etcd", "zk"):
        pid = _read_pid(name)
        if pid:
            os.kill(pid, signal.SIGKILL)
            _wait(lambda: _read_pid(name) is None, 5, f"{name} exit")
    elif name == "pg":
        subprocess.run(["pg_ctlcluster", "16", "main", "stop", "-m", "immediate"], check=False)
        _wait(lambda: not _port_open(PG_PORT), 10, "postgres down")
    else:
        raise SystemExit(f"unknown service {name}")


def stop(name: str) -> None:
    """Graceful stop (SIGTERM / SHUTDOWN). Used for planned restarts."""
    if name in ("redis-p", "redis-r"):
        port = REDIS_P_PORT if name == "redis-p" else REDIS_R_PORT
        subprocess.run([REDIS_CLI, "-p", str(port), "shutdown", "save"], check=False,
                       capture_output=True)
        _wait(lambda: not _port_open(port), 10, f"{name} down")
    elif name in ("etcd", "zk"):
        pid = _read_pid(name)
        if pid:
            os.kill(pid, signal.SIGTERM)
            _wait(lambda: _read_pid(name) is None, 15, f"{name} exit")
    elif name == "pg":
        subprocess.run(["pg_ctlcluster", "16", "main", "stop", "-m", "fast"], check=False)
    else:
        raise SystemExit(f"unknown service {name}")


def restart(name: str) -> None:
    stop(name) if name != "pg" else None
    if name == "pg":
        subprocess.run(["pg_ctlcluster", "16", "main", "restart"], check=True)
        _wait(lambda: _port_open(PG_PORT), 20, "postgres")
        return
    start(name)


def status() -> dict:
    return {
        "redis-p": _port_open(REDIS_P_PORT),
        "redis-r": _port_open(REDIS_R_PORT),
        "etcd": _port_open(ETCD_CLIENT),
        "zk": _port_open(ZK_PORT),
        "pg": _port_open(PG_PORT),
    }


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__)
        return 2
    action, names = argv[0], argv[1:]
    for n in names:
        {"start": start, "stop": stop, "kill": kill, "restart": restart}[action](n)
    print(status())
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
