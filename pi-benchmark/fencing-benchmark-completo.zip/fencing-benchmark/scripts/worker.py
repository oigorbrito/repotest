"""One independent client process (role A or B).

Started by run_bench.py as a subprocess with its own connections and its own
memory. It reads one JSON command per line on stdin and answers one JSON line on
stdout. The orchestrator can SIGSTOP / SIGCONT it to model a suspended writer.

Usage: python worker.py '<json config>'   (config: impl, owner, redis_port, dsn, ...)
"""

from __future__ import annotations

import asyncio
import json
import sys
import traceback

from adapters import REGISTRY, now_ns


async def main() -> None:
    cfg = json.loads(sys.argv[1])
    adapter = REGISTRY[cfg["impl"]](cfg)
    await adapter.connect()
    loop = asyncio.get_running_loop()
    out = sys.stdout

    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if not line:
            break
        cmd = json.loads(line)
        op = cmd["op"]
        t0 = now_ns()
        try:
            if op == "setup":
                await adapter.ensure_resource(cmd["res"])
                resp = {"status": "ok"}
            elif op == "acquire":
                resp = await adapter.acquire(cmd["res"], cmd["owner"], cmd["ttl"])
            elif op == "release":
                resp = await adapter.release(cmd["res"], cmd["owner"])
            elif op == "write":
                resp = await adapter.write(cmd["res"], cmd["key"], cmd["value"],
                                           cmd.get("token"), cmd["opid"], cmd["owner"])
            elif op == "read":
                resp = await adapter.read(cmd["res"], cmd["key"])
            elif op == "reconfigure":
                await adapter.reconnect(cmd["cfg"])
                resp = {"status": "ok"}
            elif op == "quit":
                await adapter.close()
                resp = {"status": "ok"}
            else:
                resp = {"status": "error", "detail": f"unknown op {op}"}
        except Exception as exc:  # never let a bad command kill the worker silently
            resp = {"status": "error", "detail": type(exc).__name__,
                    "trace": traceback.format_exc(limit=3)}
        t1 = now_ns()
        resp.update({"op": op, "id": cmd.get("id"), "t0": t0, "t1": t1})
        out.write(json.dumps(resp, default=str) + "\n")
        out.flush()
        if op == "quit":
            break


if __name__ == "__main__":
    asyncio.run(main())
