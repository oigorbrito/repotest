# Relatório — Benchmark comparativo de fencing

Pacote completo do benchmark: código, procedimento, dados brutos e resultados.
Detalhes numéricos completos estão em `RESULTS.md` e `results.json`.

## 1. FENCE — o que foi comparado

Dois processos independentes (A e B) disputam uma lease sobre um recurso. A adquire
(token T), pausa antes de gravar (SIGSTOP), a lease expira, B adquire (token T+1) e grava.
Quando A retoma e tenta gravar com T, o armazenamento precisa rejeitar.

| Implementação | Como o token é emitido | Onde a validação acontece |
|---|---|---|
| StatePact Redis (statepact 0.1.2) | contador do próprio StatePact | script Lua atômico no Redis |
| ZooKeeper + Redis Lua | sequência persistente do ZooKeeper (ZooKeeper 3.9.3) | script Lua único que valida e grava |
| etcd + PostgreSQL | revisão do etcd (etcd v3.5.21) | transação PostgreSQL com lock de linha, que também serializa a aquisição |
| StatePact PostgreSQL (statepact 0.1.2) | contador do próprio StatePact | `_commit_locked`, com advisory lock |
| Controle negativo (`naive_redis`) | sem token | nenhuma — serve para provar que o benchmark detecta escrita obsoleta |

Cenários (100 repetições cada, por implementação):

- **D2** — escritor antigo suspenso antes da gravação.
- **C4** — escritor antigo retomado depois que o novo dono gravou e liberou a lease.
- **CONC** — aquisição e commit simultâneos.
- **EXP_PRE / EXP_POST** — escrita após expiração, antes e depois de um novo dono.
- **LAT** — latência sequencial (acquire, write, release).
- **PGRACE** — corrida entre `acquire_lease()` e `_commit_locked()` no StatePact PostgreSQL.
- **RESTART** — reinício gracioso do coordenador; persistência e monotonicidade.
- **INTERRUPT** — coordenador derrubado com SIGKILL durante a aquisição do novo dono.
- **FAILOVER** — Redis: primário derrubado logo após o ack, réplica promovida.

## 2. HOW — como reproduzir

Requisitos: `redis-server`, `redis-cli`, PostgreSQL 16 com `pg_ctlcluster`, Java 17+, Maven,
Go 1.24, Python 3.13.

```bash
cd fencing-benchmark
bash scripts/setup_env.sh          # venv, StatePact 0.1.2, jars do ZooKeeper, etcd, role PG, sobe serviços
REPS=100 bash scripts/run_all.sh   # fase 1 (4 slots paralelos) + fase 2 (serial) + análise
```

Para uma única execução de depuração:

```bash
.venv/bin/python scripts/run_bench.py one statepact_redis D2
```

Para regenerar os números a partir dos brutos (sem rodar de novo):

```bash
.venv/bin/python scripts/analyze.py   # gera results.json e results_tables.md
```

## 3. SCRIPTS — o que cada arquivo faz

| Arquivo | Função |
|---|---|
| `scripts/setup_env.sh` | Monta o ambiente: venv, StatePact, jars do ZooKeeper (Maven), build do etcd, role PostgreSQL, serviços |
| `scripts/services.py` | Sobe, para, derruba (SIGKILL) e reinicia Redis primário/réplica, etcd, ZooKeeper e PostgreSQL, com controle de PID |
| `scripts/adapters.py` | Os quatro candidatos e o controle, com a mesma interface e os mesmos códigos de status |
| `scripts/worker.py` | Um processo cliente independente (papel A ou B), com protocolo JSON por linha |
| `scripts/run_bench.py` | Cenários, orquestração (SIGSTOP/SIGCONT), definições de violação e veredito |
| `scripts/analyze.py` | Gera `results.json` e `results_tables.md` apenas a partir de `raw/` |
| `scripts/run_all.sh` | Execução completa: fase 1, fase 2 e análise |
| `scripts/zk/pom.xml` | Dependências do ZooKeeper 3.9.3 |
| `patches/etcd-embed-launcher.go.txt` | Launcher do etcd (o único ajuste necessário para executar o candidato) |
| `patches/etcd-embed-go.mod.txt` | go.mod do launcher |
| `tools/etcd-embed/` | Código-fonte do launcher do etcd |

## 4. BATCH — o lote executado

| Item | Valor |
|---|---|
| Registros totais | 3600 (`raw/<implementação>/<cenário>.jsonl`) |
| Fase 1 (não disruptiva, 4 slots paralelos) | 2500 registros |
| Fase 2 (SIGKILL/reinício, serial) | 1100 registros |
| Repetições por cenário | 100 |
| Exceções | 0 |
| Lease TTL | 1,0 s (suspensão e espera de expiração: TTL + 0,5 s) |
| Commit de referência do repositório | `d4ba89892ea0ab61cddebfca895d945ae856411c` |

Vereditos por cenário (100 execuções cada):

| Implementação | D2 | C4 | CONC | EXP_PRE | EXP_POST | LAT | PGRACE | RESTART | INTERRUPT | FAILOVER |
|---|---|---|---|---|---|---|---|---|---|---|
| StatePact Redis | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | PASS |
| ZooKeeper + Redis Lua | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | PASS |
| etcd + PostgreSQL | PASS | PASS | PASS | FAIL | PASS | PASS | n/a | PASS | PASS | NÃO TESTADO |
| StatePact PostgreSQL | PASS | PASS | 95 PASS / 5 FAIL | FAIL | PASS | PASS | FAIL 100/100 | PASS | PASS | NÃO TESTADO |
| Controle (`naive_redis`) | — | — | — | — | — | — | — | — | — | CONTROL_DETECTED 100/100 (D2) |

Latência (p50 / p95 / p99, ms, agregada): StatePact Redis escrita 1,59 / 2,54 / 3,59;
ZooKeeper+Redis escrita 0,66 / 1,11 / 1,69; etcd+PostgreSQL escrita 1,61 / 3,30 / 5,21;
StatePact PostgreSQL escrita 7,19 / 10,23 / 17,18. Tabela completa em `results_tables.md`.

## 5. Classificação

| Implementação | Classificação |
|---|---|
| StatePact Redis | **APROVADA COM LIMITAÇÕES** |
| ZooKeeper + Redis Lua | **APROVADA COM LIMITAÇÕES** |
| etcd + PostgreSQL | **APROVADA COM LIMITAÇÕES** |
| StatePact PostgreSQL | **REPROVADA** (race do PGRACE reproduzida 100/100) |

Nenhuma chega a APROVADA: todas falham em `EXP_PRE` (escrita de dono com lease expirada,
sem novo dono, é aceita). As três "COM LIMITAÇÕES" mantiveram zero escritas obsoletas
aceitas por substituição em todos os cenários de fencing.

## 6. Limitações e NÃO TESTADO

- Interrupção **durante a gravação** não foi exercida: em 400 execuções de INTERRUPT o kill
  sempre caiu depois que a escrita já tinha retornado. Só a aquisição foi interrompida
  (etcd 100/100, ZooKeeper 97/100, StatePact Redis 43/100; StatePact PostgreSQL 0/100).
- FAILOVER só para os dois Redis; etcd e PostgreSQL sem réplica, portanto NÃO TESTADO.
- Janela de escrita não replicada no Redis não foi reproduzida (kill ≥1,5 s após o ack).
- Sem topologia multi-nó (Sentinel/Cluster, ensemble ZooKeeper, cluster etcd).
- Latência medida na fase 1 com 4 execuções paralelas.
- `mh`, FineCode e FineCore não estão neste ambiente: nada foi lido ou alterado neles, e não
  há recomendação de mudança em `mh`.

## 7. Arquivos de apoio

- `RESULTS.md` — relatório técnico completo com todas as tabelas.
- `results.json` — resultados estruturados (inclui versões e configuração).
- `results_tables.md` — tabelas geradas.
- `README.md` — procedimento de reprodução e definições de violação.
- `raw/` — um JSON por linha por execução, com a sequência de eventos.
