| impl | scenario | runs | verdicts | superseded | expired | overlap | applied_after_supersession | valid_rejected | mono | dup | lost | final_mismatch | errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| etcd_pg | C4 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | CONC | 100 | {'PASS': 100} | 0 | 13547 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | D2 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | EXP_POST | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | EXP_PRE | 100 | {'FAIL': 100} | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | INTERRUPT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100 |
| etcd_pg | LAT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| etcd_pg | RESTART | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| naive_redis | NEG_D2 | 100 | {'CONTROL_DETECTED': 100} | 100 | 0 | 0 | 0 | 0 | 100 | 100 | 0 | 100 | 0 |
| statepact_pg | C4 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | CONC | 100 | {'PASS': 95, 'FAIL': 5} | 0 | 2 | 24 | 0 | 5 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | D2 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | EXP_POST | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | EXP_PRE | 100 | {'FAIL': 100} | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | INTERRUPT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | LAT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | PGRACE | 100 | {'FAIL': 100} | 0 | 100 | 100 | 100 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_pg | RESTART | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | C4 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | CONC | 100 | {'PASS': 100} | 0 | 98 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | D2 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | EXP_POST | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | EXP_PRE | 100 | {'FAIL': 100} | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | FAILOVER | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | INTERRUPT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 43 |
| statepact_redis | LAT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| statepact_redis | RESTART | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | C4 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | CONC | 100 | {'PASS': 100} | 0 | 513 | 13 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | D2 | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | EXP_POST | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | EXP_PRE | 100 | {'FAIL': 100} | 0 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | FAILOVER | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | INTERRUPT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 97 |
| zk_redis_lua | LAT | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| zk_redis_lua | RESTART | 100 | {'PASS': 100} | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

| impl | op | n | p50 ms | p95 ms | p99 ms |
|---|---|---|---|---|---|
| etcd_pg | acquire | 4350 | 9.45 | 565.449 | 887.66 |
| etcd_pg | release | 1100 | 2.981 | 5.683 | 9.635 |
| etcd_pg | write | 66691 | 1.606 | 3.302 | 5.213 |
| naive_redis | acquire | 200 | 1.837 | 2.992 | 3.562 |
| naive_redis | write | 300 | 0.669 | 2.168 | 3.366 |
| statepact_pg | acquire | 2900 | 2.804 | 5.165 | 6.521 |
| statepact_pg | release | 1100 | 0.914 | 1.901 | 3.404 |
| statepact_pg | write | 15312 | 7.189 | 10.229 | 17.179 |
| statepact_redis | acquire | 3011 | 1.073 | 3.155 | 123.1 |
| statepact_redis | release | 1100 | 0.592 | 1.113 | 1.887 |
| statepact_redis | write | 52401 | 1.585 | 2.536 | 3.594 |
| zk_redis_lua | acquire | 2990 | 3.713 | 11.303 | 603.573 |
| zk_redis_lua | release | 1100 | 0.617 | 1.203 | 1.771 |
| zk_redis_lua | write | 99419 | 0.66 | 1.114 | 1.691 |

| impl | scenario | acquire recovery p50/p95/max ms | write recovery p50/p95/max ms | effects histogram |
|---|---|---|---|---|
| etcd_pg | INTERRUPT | 810.008 / 1014.015 / 1055.923 (n=100) | None / None / None (n=0) | {1: 100} |
| statepact_redis | INTERRUPT | 4173.976 / 4905.078 / 4985.86 (n=43) | None / None / None (n=0) | {1: 100} |
| zk_redis_lua | INTERRUPT | 716.004 / 1207.79 / 10672.992 (n=97) | None / None / None (n=0) | {1: 100} |
