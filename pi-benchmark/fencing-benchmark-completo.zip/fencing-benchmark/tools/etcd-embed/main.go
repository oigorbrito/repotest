// Minimal launcher for the upstream etcd v3.5.21 server, using the published
// go.etcd.io/etcd/server/v3/embed package. Needed because `go install` of the
// etcd repository's own main package is refused by its go.mod replace directives.
package main

import (
	"flag"
	"fmt"
	"os"
	"net/url"
	"os/signal"
	"syscall"
	"time"

	"go.etcd.io/etcd/server/v3/embed"
)

func main() {
	dir := flag.String("data-dir", "", "data dir")
	client := flag.String("client", "http://127.0.0.1:2379", "client URL")
	peer := flag.String("peer", "http://127.0.0.1:2380", "peer URL")
	flag.Parse()
	cfg := embed.NewConfig()
	cfg.Dir = *dir
	cfg.LogLevel = "error"
	cfg.TickMs = 50
	cfg.ElectionMs = 500 // min lease TTL ~0.75s; keeps 1s benchmark TTL valid
	u := func(s string) []string { return []string{s} }
	lc, _ := parseURL(*client)
	lp, _ := parseURL(*peer)
	cfg.ListenClientUrls = lc
	cfg.AdvertiseClientUrls = lc
	cfg.ListenPeerUrls = lp
	cfg.AdvertisePeerUrls = lp
	cfg.InitialCluster = cfg.Name + "=" + u(*peer)[0]
	e, err := embed.StartEtcd(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer e.Close()
	select {
	case <-e.Server.ReadyNotify():
		fmt.Println("etcd ready")
	case <-time.After(60 * time.Second):
		fmt.Println("etcd start timeout")
		os.Exit(1)
	}
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGTERM, syscall.SIGINT)
	select {
	case <-ch:
	case err := <-e.Err():
		fmt.Fprintln(os.Stderr, err)
	}
}

func parseURL(s string) ([]url.URL, error) {
	u, err := url.Parse(s)
	if err != nil {
		return nil, err
	}
	return []url.URL{*u}, nil
}
